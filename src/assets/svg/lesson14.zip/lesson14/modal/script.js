function Modal(modalSelector) {
  const modal = document.querySelector(modalSelector);

  this.init = function (openSelector, closeSelector) {
    const openElement = document.querySelector(openSelector);
    openElement.addEventListener('click', this.openModal);

    const closeElement = document.querySelector(closeSelector);
    closeElement.addEventListener('click', this.closeModal);

    window.addEventListener('click', (event) => this.closeModalOutside(event));
  }

  this.openModal = function () {
    modal.style.display = 'block';
  }

  this.closeModal = function () {
    modal.style.display = 'none';
  }

  this.closeModalOutside = function (event) {
    if (event.target === modal) {
      this.closeModal();
    }
  }
}

const firstModal = new Modal('.js--modal');
firstModal.init('.js--open', '.js--modal__close');

const secondModal = new Modal('.js--modal');
secondModal.init('.js--open2', '.js--modal__close');

const thirdModal = new Modal('.js--modal2');
thirdModal.init('.js--open3', '.js--modal__close');